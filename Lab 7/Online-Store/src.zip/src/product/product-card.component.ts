import { Component, Input } from '@angular/core';
import { Product } from './product.model';

@Component({
  selector: 'app-product-card',
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.css']
})
export class ProductCardComponent {
  @Input() product!: Product;

  // Функция для смены изображения
  changeImage(direction: number) {
    if (!this.product || !this.product.images) return;

    const totalImages = this.product.images.length;
    this.product.currentImageIndex = (this.product.currentImageIndex! + direction + totalImages) % totalImages;
  }
}
