import { Component } from '@angular/core';
import { PRODUCTS } from '../product/products';
import { Product } from '../product/product.model';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})


export class AppComponent {
  products: Product[] = PRODUCTS;
}
